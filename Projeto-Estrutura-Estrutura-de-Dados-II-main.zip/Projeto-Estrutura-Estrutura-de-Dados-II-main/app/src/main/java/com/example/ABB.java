package com.example;

import java.util.LinkedList;
import java.util.Queue;

public class ABB<E extends Comparable<E>> {

    private NoABB<E> raiz;

    public ABB() {
        raiz = null;
    }

    public NoABB<E> getRaiz() {
        return raiz;
    }

    public void setRaiz(NoABB<E> raiz) {
        this.raiz = raiz;
    }

    public boolean isEmpty() {
        return raiz == null;
    }

    public E inserir(E valor) {
        NoABB<E> novo = new NoABB<>(valor);
        raiz = inserir(novo, raiz);
        return valor;
    }

    private NoABB<E> inserir(NoABB<E> novo, NoABB<E> anterior) {
        if (anterior == null) {
            return novo; 
        }

        if (novo.getValue().compareTo(anterior.getValue()) < 0) {
            anterior.setFilhoEsq(
                inserir(novo, anterior.getFilhoEsq())
            );
        } else {
            anterior.setFilhoDir(
                inserir(novo, anterior.getFilhoDir())
            );
        }

        return anterior;
    }

    public void emOrdem() {
        emOrdem(raiz);
    }

    private void emOrdem(NoABB<E> no) {
        if (no != null) {
            emOrdem(no.getFilhoEsq());
            System.out.print(no.getValue() + " ");
            emOrdem(no.getFilhoDir());
        }
    }

    public void preOrdem() {
        preOrdem(raiz);
    }

    private void preOrdem(NoABB<E> no) {
        if (no != null) {
            System.out.print(no.getValue() + " ");
            preOrdem(no.getFilhoEsq());
            preOrdem(no.getFilhoDir());
        }
    }

    public void posOrdem() {
        posOrdem(raiz);
    }

    private void posOrdem(NoABB<E> no) {
        if (no != null) {
            posOrdem(no.getFilhoEsq());
            posOrdem(no.getFilhoDir());
            System.out.print(no.getValue() + " ");
        }
    }

    public void emNivel() {
        if (raiz == null) return;

        Queue<NoABB<E>> fila = new LinkedList<>();
        fila.add(raiz);

        while (!fila.isEmpty()) {
            NoABB<E> atual = fila.poll();
            System.out.print(atual.getValue() + " ");

            if (atual.getFilhoEsq() != null)
                fila.add(atual.getFilhoEsq());
            if (atual.getFilhoDir() != null)
                fila.add(atual.getFilhoDir());
        }
    }

    public NoABB<E> getMax(NoABB<E> raiz, NoABB<E> paiRaiz) {
        if (raiz == null)
            return null;


        if (raiz.getFilhoDir() == null) {

            if (paiRaiz != null) {
                if (paiRaiz.getFilhoEsq() == raiz) {
                    paiRaiz.setFilhoEsq(raiz.getFilhoEsq());
                } else {
                    paiRaiz.setFilhoDir(raiz.getFilhoEsq());
                }
            }

            return raiz;
        }

        return getMax(raiz.getFilhoDir(), raiz);
    }

    private int compara(E ob1, E ob2) {
        return ob1.compareTo(ob2);
    }

    public boolean eliminar(E e) {
        return eliminar(raiz, null, e);
    }

    private boolean eliminar(NoABB<E> node, NoABB<E> paiRaiz, E e) {

        if (node == null) {
            return false; 
        }

        int cmp = compara(e, node.getValue());

        if (cmp == 0) {

            if (node.getFilhoEsq() == null && node.getFilhoDir() == null) {
                if (paiRaiz == null) {
                    raiz = null;
                } else if (paiRaiz.getFilhoEsq() == node) {
                    paiRaiz.setFilhoEsq(null);
                } else {
                    paiRaiz.setFilhoDir(null);
                }
            }

            else if (node.getFilhoDir() == null) {
                if (paiRaiz == null) {
                    raiz = node.getFilhoEsq();
                } else if (paiRaiz.getFilhoEsq() == node) {
                    paiRaiz.setFilhoEsq(node.getFilhoEsq());
                } else {
                    paiRaiz.setFilhoDir(node.getFilhoEsq());
                }
            }

            else if (node.getFilhoEsq() == null) {
                if (paiRaiz == null) {
                    raiz = node.getFilhoDir();
                } else if (paiRaiz.getFilhoEsq() == node) {
                    paiRaiz.setFilhoEsq(node.getFilhoDir());
                } else {
                    paiRaiz.setFilhoDir(node.getFilhoDir());
                }
            }

            else {
                NoABB<E> maior = getMax(node.getFilhoEsq(), node);
                node.setValue(maior.getValue());
            }

            return true;
        }

        if (cmp < 0) {
            return eliminar(node.getFilhoEsq(), node, e);
        }

        return eliminar(node.getFilhoDir(), node, e);
    }
}
